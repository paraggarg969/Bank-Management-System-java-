//Importing files
package User_Info;
import Registration_Login.Registration_Login;
import java.io.FileWriter;
import java.io.IOException;

public class User_Info extends Registration_Login {
    
    int money;

    public User_Info(String name, String Username, String num, String password, String type, String number,String transaction,String FilePath) {
        super(name, Username, num, password, type, number);
        this.money = 0;
        try {
            FileWriter fwrite = new FileWriter(FilePath + this.getUsername() + ".txt",true);
            fwrite.write(this.money + "\r\n" + this.getName() + "\r\n" + this.getUsername() + "\r\n" + this.getnum() + "\r\n"+ this.getPassword() + "\r\n" + this.getType()+"\r\n" + this.getNumber() + "\r\n"+transaction+"\r\n");
            fwrite.close();

        } catch (IOException e) {
            System.out.println("Unexpected error occurred");
            e.printStackTrace();
        }
    }

    public void message() {
        System.out.println("ACCOUNT CREATED SUCCESFULLY !");
    }
}
