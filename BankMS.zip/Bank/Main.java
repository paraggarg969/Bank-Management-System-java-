import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

import User_Info.User_Info;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        Scanner sc = new Scanner(System.in);

        String type;
        String FilePath = "./";

        boolean b = true;

        while (b) {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            System.out.println("Welcome to BANK !!!\n");
            System.out.println("1. Create New Account");
            System.out.println("2. Login for Existing Account");
            System.out.println("3. Delete Account");
            System.out.println("4. Exit ");
            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();
           
                if (choice == 1) {

                    System.out.print("Enter Name : ");
                    sc.nextLine();
                    String name = sc.nextLine();

                    System.out.print("Enter Username : ");
                    String username = sc.nextLine();

                    File file = new File(FilePath + username + ".txt");
                    if (!file.exists()) {


                    System.out.print("Account Number : ");

                    Random random = new Random();
                    long random16DigitNumber = (long) (Math.pow(10, 15) + random.nextDouble() * Math.pow(10,15));
                    String strRandomNumber = String.valueOf(random16DigitNumber);
                    String Accountnumber = strRandomNumber;
                    System.out.println(Accountnumber);

                    System.out.print("Please Enter Which Type Of Account you want to open (saving/current) : ");
                    type = sc.nextLine();

                    if(type.equalsIgnoreCase("saving") || type.equalsIgnoreCase("current")){

                    System.out.print("Enter Phone Number : ");
                    String number = sc.nextLine();
                
                    if (number.length() == 10 && number.matches("\\d+")) {

                    Console console = System.console();
                    if (console == null) {
                        System.out.println("Couldn't get Console instance");
                        System.exit(0);
                    }
                    char[] passwordArray = console.readPassword("Enter your secret password: (It won't show due to security reasons) : ");
                    String password = new String(passwordArray);

                    System.out.println("Password Length : " + password.length() + ".");

                    User_Info reg = new User_Info(name, username, Accountnumber, password, type, number, "TRANSACTION:0", FilePath);
                    reg.message();

                    System.out.println("\nPress enter to continue");
                    try {
                        System.in.read();
                    } catch (Exception e) {
                    }
                }
                else{
                    System.out.println("Enter Invalid Phone number (Must be 10 digits)!");
                    System.out.println("\nPress enter to continue");
                    try {
                        System.in.read();
                    } catch (Exception e) {
                    }
                    continue;
                    }
                }           
                else {
                    System.out.println("invaild account type !");
                        System.out.println("\nPress enter to continue");
                        try {
                            System.in.read();
                        } catch (Exception e) {
                        }
                       continue;
                }
            }
            else{
                 System.out.println("username Already Taken !");
                    System.out.println("\nPress enter to continue");
                    try {
                        System.in.read();
                    } catch (Exception e) {
                    }
                    continue;
                }
            }

                else if (choice == 2) {
                    System.out.println();
                    System.out.print("Enter username : ");
                    sc.nextLine();
                    String username = sc.nextLine();

                    Console console = System.console();
                    if (console == null) {
                        System.out.println("Couldn't get Console instance");
                        System.exit(0);
                    }
                    char[] passwordArray = console.readPassword("Enter your secret password: (It won't show due to security reasons) : ");
                    String password = new String(passwordArray);

                    boolean bool = true;

                    File file = new File(FilePath + username + ".txt");

                    if (file.exists()) {
                        try {
                            // Take file data in variables
                            Scanner dataReader = new Scanner(file);
                            String money = dataReader.nextLine();
                            int login_money = Integer.parseInt(money);
                            String login_name = dataReader.nextLine();
                            String login_username = dataReader.nextLine();
                            String login_accnum = dataReader.nextLine();
                            String login_password = dataReader.nextLine();
                            String number = dataReader.nextLine();
                            String login_type = dataReader.nextLine();
                            String login_transaction = dataReader.nextLine();
                            if (username.equals(login_username) && password.equals(login_password)) {

                                // -----------------------------------------------------------------

                                boolean bo = true;
                                // Menu for logged in customers
                                while (bo) {
                                    new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                                    System.out.println("Welcome " + login_name + " !");
                                    System.out.println("\n**** OPERATIONS ****");
                                    System.out.println("1. Deposit Money");
                                    System.out.println("2. Withdraw Money");
                                    System.out.println("3. View Details/Balance");
                                    System.out.println("4. View Transaction History");
                                    System.out.println("5. Transfer to other account");
                                    System.out.println("6. Logout ");
                                    System.out.print("Enter Choice : ");
                                    int choice2 = sc.nextInt();
                                    System.out.println();

                                    // Deposit Method
                                    if (choice2 == 1) {
                                        System.out.print("Enter Amount to Deposit : (Limit : 50,000) : ");
                                        int amount = sc.nextInt();

                                        if (amount < 0 || amount > 50000) {
                                            System.out.println("Enter correct amount !");
                                            System.out.println("\nPress enter to continue");
                                            try {
                                                System.in.read();
                                            } catch (Exception e) {
                                            }
                                        } else {
                                            try {
                                                FileWriter f0 = new FileWriter(FilePath + username + ".txt", true);
                                                String old_money = Integer.toString(login_money);
                                                login_money += amount;
                                                int temp = amount;
                                                String to_be_deposited = Integer.toString(login_money);
                                                modifyFile(FilePath + username + ".txt", old_money, to_be_deposited);

                                                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                                Date date = new Date();
                                                f0.write("Rs.(+" + temp + ") :: " + formatter.format(date)    + " :: Self Deposit " + "\n");

                                                login_transaction = "TRANSACTION:1";
                                                modifyFile(FilePath + username + ".txt", "TRANSACTION:0","TRANSACTION:1");

                                                System.out.println("Rs. " + temp + " Deposited !");

                                                System.out.println("\nPress enter to continue");
                                                try {
                                                    System.in.read();
                                                } catch (Exception e) {
                                                }

                                                f0.close();
                                            } catch (IOException e) {
                                                System.out.println("User Data not found !");
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                    // Withdraw method
                                    else if (choice2 == 2) {
                                        System.out.println("Enter Amount to Withdraw : (Limit : 0 to " + login_money + ")");
                                        int amount_withdraw = sc.nextInt();
                                        if (amount_withdraw < 0 || amount_withdraw > login_money) {
                                            System.out.println("Enter correct amount !");
                                            System.out.println("\nPress enter to continue");
                                            try {
                                                System.in.read();
                                            } catch (Exception e) {
                                            }
                                        } else {
                                            try {
                                                FileWriter f0 = new FileWriter(FilePath + username + ".txt", true);
                                                String old_money = Integer.toString(login_money);
                                                login_money -= amount_withdraw;
                                                int temp1 = amount_withdraw;
                                                String to_be_withdrawed = Integer.toString(login_money);
                                                modifyFile(FilePath + username + ".txt", old_money, to_be_withdrawed);

                                                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                                Date date = new Date();
                                                f0.write("Rs.(-" + temp1 + ") :: " + formatter.format(date)    + " :: Self Withdraw" + "\n");

                                                login_transaction = "TRANSACTION:1";
                                                modifyFile(FilePath + username + ".txt", "TRANSACTION:0","TRANSACTION:1");

                                                System.out.println("Rs. " + temp1 + " Withdrawn !");

                                                System.out.println("\nPress enter to continue");
                                                try {
                                                    System.in.read();
                                                } catch (Exception e) {
                                                }

                                                f0.close();
                                            } catch (IOException e) {
                                                System.out.println("User Data not found !");
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                    // Shwo all details from variables that we stored file contents
                                    else if (choice2 == 3) {
                                        System.out.println("\nDetails :");
                                        System.out.println("1. Name          : " + login_name);
                                        System.out.println("2. username      : " + login_username);
                                        System.out.println("2. Account number: " + login_accnum);
                                        System.out.printf("3. Password      : ");
                                        for (int i = 0; i < login_password.length(); i++) {
                                            System.out.printf("*");
                                        }
                                        System.out.println();
                                        System.out.println("4. Phone No.     : " + number);
                                        System.out.println("5. Account Type  : " + login_type);
                                        System.out.println("6. Balance       : " + login_money + " Rs.");

                                        System.out.println("\nPress enter to continue");
                                        try {
                                            System.in.read();
                                        } catch (Exception e) {
                                        }
                                    }
                                    // Transaction history (Show only if TRANSACTION:1 is there, Don't show if
                                    // TRANSACTION:0 is there in file variable)
                                    else if (choice2 == 4) {
                                        try {
                                            File f1 = new File(FilePath + username + ".txt");
                                            dataReader = new Scanner(f1);
                                            System.out.println("Transaction History : ");
                                            String temp = "TRANSACTION:0";
                                            if (login_transaction.equals(temp)) {
                                                System.out.println("No Transaction History is there !");
                                                System.out.println("\nPress enter to continue");
                                                try {
                                                    System.in.read();
                                                } catch (Exception e) {
                                                }
                                            } else {
                                                for (int j = 0; j < 6; j++) {
                                                    dataReader.nextLine();
                                                }
                                                while (dataReader.hasNextLine()) {
                                                    String fileData = dataReader.nextLine();
                                                    System.out.println(fileData);
                                                }
                                                System.out.println("\nPress enter to continue");
                                                try {
                                                    System.in.read();
                                                } catch (Exception e) {
                                                }
                                            }
                                            dataReader.close();
                                        } catch (FileNotFoundException exception) {
                                            System.out.println("Unexcpected error occurred!");
                                            exception.printStackTrace();
                                            System.out.println("\nPress enter to continue");
                                            try {
                                                System.in.read();
                                            } catch (Exception e) {
                                            }
                                        }
                                    }
                                    // Transfer to other account with username and update amount and transaction
                                    else if (choice2 == 5) {
                                        System.out.println();
                                        System.out.print("Enter username of other account: ");
                                        sc.nextLine();
                                        String username_to_transfer = sc.nextLine();

                                        File file_to_transfer = new File(FilePath + username_to_transfer + ".txt");
                                        if (file_to_transfer.exists()) {
                                            // dataReader = new Scanner(file_to_transfer);
                                            Scanner dataReader2 = new Scanner(file_to_transfer);
                                            String money_old = dataReader2.nextLine();
                                            String name_transfer = dataReader2.nextLine();
                                            int money_old_user = Integer.parseInt(money_old);
                                            System.out.print("Enter Amount to Transfer : (Limit : 0 to " + login_money + ") : ");
                                            int amount_transfer_update = sc.nextInt();

                                            if (amount_transfer_update <= 0 || amount_transfer_update > login_money) {
                                                System.out.println("Enter correct amount !");
                                                System.out.println("\nPress enter to continue");
                                                try {
                                                    System.in.read();
                                                } catch (Exception e) {
                                                }
                                            } else {
                                                String to_upd = Integer.toString(login_money);
                                                login_money -= amount_transfer_update;
                                                String to_upd2 = Integer.toString(login_money);
                                                modifyFile(FilePath + username + ".txt", to_upd, to_upd2);

                                                String to_update = Integer.toString(money_old_user);
                                                money_old_user += amount_transfer_update;
                                                String to_update_2 = Integer.toString(money_old_user);
                                                modifyFile(FilePath + username_to_transfer + ".txt", to_update,to_update_2);
                                                modifyFile(FilePath + username_to_transfer + ".txt", "TRANSACTION:0","TRANSACTION:1");
                                                try {
                                                    FileWriter f11 = new FileWriter(FilePath + username_to_transfer + ".txt", true);
                                                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                                    Date date = new Date();
                                                    f11.write("Rs.(+" + amount_transfer_update + ") :: " + formatter.format(date) + " :: Transferred from " + username + " (" + login_name + ")\n");
                                                    f11.close();

                                                    FileWriter f12 = new FileWriter(FilePath + username + ".txt", true);
                                                    SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                                                    Date date2 = new Date();
                                                    f12.write("Rs.(-" + amount_transfer_update + ") :: " + formatter2.format(date2) + " :: Transferred to " + username_to_transfer + " (" + name_transfer + ")\n");
                                                    f12.close();

                                                    System.out.println("Rs.(" + amount_transfer_update + ") Transferred to " + username_to_transfer + " ( " + name_transfer + " )");
                                                    System.out.println("\nPress enter to continue");
                                                    try {
                                                        System.in.read();
                                                    } catch (Exception e) {
                                                    }

                                                } catch (IOException e) {
                                                    System.out.println("User Data not found !");
                                                    e.printStackTrace();
                                                }
                                            }
                                            dataReader2.close();
                                        } else {
                                            System.out.println("USER DON'T EXISTS !");
                                            System.out.println("\nPress enter to continue");
                                            try {
                                                System.in.read();
                                            } catch (Exception e) {
                                            }
                                        }
                                    } else if(choice2 == 6){
                                        System.out.println("\n***** Thank you for using ATM *****");
                                        break;   
                                    }
                                    else{
                                        System.out.println("Please Enter Correct Choice !");
                                        System.out.println("USER DON'T EXISTS !");
                                        System.out.println("\nPress enter to continue");
                                        try {
                                            System.in.read();
                                        } catch (Exception e) {
                                        }
                                    }
                                }
                                sc.close();
                                // -------------------------------------------------------------------
                                bool = false;
                                break;
                            }

                            dataReader.close();
                        } catch (FileNotFoundException e) {
                            System.out.println("File not found !");
                            e.printStackTrace();
                            System.out.println("\nPress enter to continue");
                            try {
                                System.in.read();
                            } catch (Exception f) {
                            }
                        }
                    } else {
                        System.out.println("User not registered!");
                        System.out.println("\nPress enter to continue");
                        try {
                            System.in.read();
                        } catch (Exception e) {
                        }
                    }

                    if (bool) {
                        System.out.println("username or Password Incorrect !\nPlease Try Again");
                        System.out.println("\nPress enter to continue");
                        try {
                            System.in.read();
                        } catch (Exception e) {
                        }
                    }

                    // if (bool) {
                    //     System.out.println("Please Enter Correct Phone Number !\nPlease Try Again");
                    //     System.out.println("\nPress enter to continue");
                    //     try {
                    //         System.in.read();
                    //     } catch (Exception e) {
                    //     }
                    // }

                } 
                else if(choice == 3){
                    System.out.println();
                    System.out.print("Enter username to Delete Account : ");
                    sc.nextLine();
                    String deleteUsername = sc.nextLine();
                    File fileToDelete = new File(FilePath + deleteUsername + ".txt");
                    
                   if (fileToDelete.exists()) {
                        if (fileToDelete.delete()) {
                            System.out.println("Account for " + deleteUsername + " deleted successfully!");
                        } else {
                            System.out.println("Failed to delete account. Please try again later.");
                        }
                    } else {
                        System.out.println("User not found!");
                    }
                
                    System.out.println("\nPress enter to continue");
                    try {
                        System.in.read();
                    } catch (Exception e) {
                    }
                }
                else if (choice == 4) {
                    System.out.println("\n***** Thank you for Coming *****");
                    sc.close();
                    b = false;
                } else {
                    System.out.println("Enter correct number input !");
                    System.out.println("\nPress enter to continue");
                    try {
                        System.in.read();
                    } catch (Exception e) {
                    }
                }
            }
            System.out.println();
        }

    static void modifyFile(String filePath, String oldString, String newString) {
        String oldContent = "";
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            while (line != null) {
                oldContent = oldContent + line + System.lineSeparator();

                line = reader.readLine();   
            }
            String newContent = oldContent.replaceFirst(oldString, newString);

            new FileWriter(filePath, false).close();
            FileWriter writer = new FileWriter(filePath);
            writer.write(newContent);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}